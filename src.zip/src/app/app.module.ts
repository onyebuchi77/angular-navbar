import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { NavbarComponent } from './navbar/navbar.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import {RouterModule, Routes} from '@angular/router';
import { MatButtonModule,MatNativeDateModule, MatIconModule,MatSidenavModule, MatListModule} from '@angular/material';
const appRoutes: Routes=[
{path: '', component :HomepageComponent},
{path: 'nav', component : NavbarComponent }
]
@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    NavbarComponent
  ],
  imports: [
    [RouterModule.forRoot(appRoutes,{enableTracing:true})],
    BrowserModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatButtonModule,MatNativeDateModule, MatIconModule,MatSidenavModule, MatListModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
